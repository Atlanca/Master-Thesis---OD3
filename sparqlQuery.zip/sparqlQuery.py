from owlready2 import *

onto = get_ontology("file://rootontologyV3.owl").load()
ra = onto.search(partOf = "*")
sync_reasoner()
graph = default_world.as_rdflib_graph()
rb = onto.search(partOf = "*")

print(len(ra))
print(len(rb))

def getAllRelations(individual):
    relationsQuery = """\
PREFIX base: <http://www.semanticweb.org/mahsaro/ontologies/2018/2/untitled-ontology-5#> \
SELECT ?p \
WHERE {{ \
base:{individual} ?p ?o \
}}""".format(individual=individual)

    relationsResult = list(graph.query(relationsQuery))
    for r in relationsResult:
        print(r)

getAllRelations("choice_three_tier_client_server_1")